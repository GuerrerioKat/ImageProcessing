Team Members: Katherine Guerrerio (kguerre6) and Angela Guo (aguo14)

Milestone 1--------------------------------------------------------
We used VSCode Live Share to work on almost all functions together.

Katherine:
- imgproc_mirror_h
- imgproc_mirror_v
- imgproc_tile
- imgproc_grayscale
- imgproc_composite
- all_tiles_nonempty
- determine_tile_w
- determine_tile_x_offset
- determine_tile_h
- determine_tile_y_offset
- copy_tile
- to_grayscale
- blend_components
- helper test cases

Angela:
- get_r
- get_g
- get_b
- get_a
- make_pixel
- blend_components
- blend_color
- most helper test cases